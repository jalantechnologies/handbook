from typing import Any
from modules.comment.internal.store.comment_model import CommentModel
from modules.comment.types import Comment

class CommentUtil:
    @staticmethod
    def convert_comment_bson_to_comment(comment_bson: dict[str, Any]) -> Comment:
        c = CommentModel.from_bson(comment_bson)
        return Comment(
            id=str(c.id),
            task_id=c.task_id,
            account_id=c.account_id,
            text=c.text,
        )
