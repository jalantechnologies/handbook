from datetime import datetime
from bson import ObjectId
from pymongo import ReturnDocument
from modules.comment.errors import CommentNotFoundError
from modules.comment.internal.store.comment_model import CommentModel
from modules.comment.internal.store.comment_repository import CommentRepository
from modules.comment.types import (
    Comment,
    CommentDeletionResult,
    CreateCommentParams,
    UpdateCommentParams,
    DeleteCommentParams,
)


class CommentWriter:
    @staticmethod
    def create_comment(*, params: CreateCommentParams) -> Comment:
        comment_bson = CommentModel(
            task_id=params.task_id, account_id=params.account_id, text=params.text
        ).to_bson()
        result = CommentRepository.collection().insert_one(comment_bson)
        created = CommentRepository.collection().find_one({"_id": result.inserted_id})
        return Comment.from_bson(created)

    @staticmethod
    def update_comment(*, params: UpdateCommentParams) -> Comment:
        updated = CommentRepository.collection().find_one_and_update(
            {"_id": ObjectId(params.comment_id), "task_id": params.task_id, "active": True},
            {"$set": {"text": params.text, "updated_at": datetime.now()}},
            return_document=ReturnDocument.AFTER,
        )
        if not updated:
            raise CommentNotFoundError(comment_id=params.comment_id)
        return Comment.from_bson(updated)

    @staticmethod
    def delete_comment(*, params: DeleteCommentParams) -> CommentDeletionResult:
        deleted = CommentRepository.collection().find_one_and_update(
            {"_id": ObjectId(params.comment_id), "task_id": params.task_id, "active": True},
            {"$set": {"active": False, "updated_at": datetime.now()}},
            return_document=ReturnDocument.AFTER,
        )
        if not deleted:
            raise CommentNotFoundError(comment_id=params.comment_id)
        return CommentDeletionResult(comment_id=params.comment_id, success=True)
