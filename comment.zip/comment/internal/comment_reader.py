from bson import ObjectId
from modules.comment.errors import CommentNotFoundError
from modules.comment.internal.store.comment_repository import CommentRepository
from modules.comment.types import Comment, GetCommentParams, GetCommentsForTaskParams


class CommentReader:
    @staticmethod
    def get_comment(*, params: GetCommentParams) -> Comment:
        c_bson = CommentRepository.collection().find_one(
            {"_id": ObjectId(params.comment_id), "task_id": params.task_id, "active": True}
        )
        if not c_bson:
            raise CommentNotFoundError(comment_id=params.comment_id)
        return Comment.from_bson(c_bson)

    @staticmethod
    def get_comments_for_task(*, params: GetCommentsForTaskParams) -> list[Comment]:
        cursor = CommentRepository.collection().find(
            {"task_id": params.task_id, "active": True}
        ).sort([("created_at", -1)])
        return [Comment.from_bson(c) for c in cursor]
