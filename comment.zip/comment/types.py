from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Comment:
    id: str
    task_id: str
    account_id: str
    text: str

    @classmethod
    def from_bson(cls, bson_data: dict) -> "Comment":
        return cls(
            id=str(bson_data.get("_id")),
            task_id=str(bson_data.get("task_id")),
            account_id=bson_data.get("account_id", ""),
            text=bson_data.get("text", ""),
        )


@dataclass(frozen=True)
class CreateCommentParams:
    task_id: str
    account_id: str
    text: str


@dataclass(frozen=True)
class UpdateCommentParams:
    comment_id: str
    task_id: str
    account_id: str
    text: str


@dataclass(frozen=True)
class DeleteCommentParams:
    comment_id: str
    task_id: str
    account_id: str


@dataclass(frozen=True)
class GetCommentParams:
    comment_id: str
    task_id: str
    account_id: str


@dataclass(frozen=True)
class GetCommentsForTaskParams:
    task_id: str
    account_id: str


@dataclass(frozen=True)
class CommentDeletionResult:
    comment_id: str
    success: bool
    deleted_at: datetime | None = None


@dataclass(frozen=True)
class CommentErrorCode:
    NOT_FOUND: str = "COMMENT_ERR_01"
    BAD_REQUEST: str = "COMMENT_ERR_02"
