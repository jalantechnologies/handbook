from dataclasses import asdict
from flask import jsonify, request
from flask.typing import ResponseReturnValue
from flask.views import MethodView
from modules.authentication.rest_api.access_auth_middleware import access_auth_middleware
from modules.comment.comment_service import CommentService
from modules.comment.errors import CommentBadRequestError
from modules.comment.types import (
    CreateCommentParams,
    UpdateCommentParams,
    DeleteCommentParams,
    GetCommentsForTaskParams,
)


class CommentView(MethodView):
    @access_auth_middleware
    def post(self, account_id: str, task_id: str) -> ResponseReturnValue:
        data = request.get_json()
        if not data or not data.get("text"):
            raise CommentBadRequestError("Text is required")

        params = CreateCommentParams(task_id=task_id, account_id=account_id, text=data["text"])
        comment = CommentService.create_comment(params=params)
        return jsonify(asdict(comment)), 201

    @access_auth_middleware
    def get(self, account_id: str, task_id: str) -> ResponseReturnValue:
        params = GetCommentsForTaskParams(task_id=task_id, account_id=account_id)
        comments = CommentService.get_comments_for_task(params=params)
        return jsonify([asdict(c) for c in comments]), 200

    @access_auth_middleware
    def patch(self, account_id: str, task_id: str, comment_id: str) -> ResponseReturnValue:
        data = request.get_json()
        if not data or not data.get("text"):
            raise CommentBadRequestError("Text is required")

        params = UpdateCommentParams(
            comment_id=comment_id, task_id=task_id, account_id=account_id, text=data["text"]
        )
        updated = CommentService.update_comment(params=params)
        return jsonify(asdict(updated)), 200

    @access_auth_middleware
    def delete(self, account_id: str, task_id: str, comment_id: str) -> ResponseReturnValue:
        params = DeleteCommentParams(comment_id=comment_id, task_id=task_id, account_id=account_id)
        CommentService.delete_comment(params=params)
        return "", 204
